﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace cigany
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public int hny = 0;
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        struct adat
        {
            public string felh;
            public string jelsz;
        }

        adat[] Olvasott(string ut)
        {
            string [] tmb = File.ReadAllLines(ut);
            adat[] t = new adat[tmb.Length];
            for (int i = 0; i < tmb.Length; i++)
            {
                string[] split = tmb[i].Split(' ');
                t[i].felh = split[0];
                t[i].jelsz = split[1];
            }
            return t;
        }

        private void Butt_Click(object sender, RoutedEventArgs e)
        {
            string fn = Name.Text;
            string jsz = Pw.Password;
            adat [] nevek = Olvasott("felh.txt");
            bool belephet = false;

            for (int i = 0; i < nevek.Length; i++)
            {
                if (fn == nevek[i].felh && jsz == nevek[i].jelsz)
                {
                    belephet = true;
                }
            }
            if (belephet)
            {
                MessageBox.Show("Sikeres bejelentkezés");
                Inner ujablak = new Inner();
                ujablak.Show();
                this.Close();

            }
            else
            {
                Name.Clear();
                Pw.Clear();
                hny++;
                if (hny == 3)
                {
                    this.Close();
                }
                MessageBox.Show("Sikertelen bejelentkezés");

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string fn = Name.Text;
            string jsz = Pw.Password;
            adat[] t = Olvasott("felh.txt");
            bool regizhet = true;

            for (int i = 0; i < t.Length; i++)
            {
                if (t[i].felh == fn)
                {
                    regizhet = false;
                }
            }
            if (!regizhet)
            {
                MessageBox.Show("Már van ilyen felhasznalo.");
                Name.Clear();
                Pw.Clear();
            }
            else
            {
                string s = fn + " " + jsz + "\n";
                File.AppendAllText("felh.txt", s);
                MessageBox.Show("Sikeres Regisztrálás.");
            }
        }

        private void Name_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            string nv = Name.Text;

            if (nv.Contains(" ") || nv == "")
            {
                Regist.IsEnabled = false;
                Butt.IsEnabled = false;
            }
            else
            {
                Regist.IsEnabled = true;
                Butt.IsEnabled = true;
            }
        }
    }
}

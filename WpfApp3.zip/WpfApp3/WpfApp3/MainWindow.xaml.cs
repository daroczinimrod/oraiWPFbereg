﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Kilep_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        public int pp = 0;
        private void BelepGomb_Click(object sender, RoutedEventArgs e)
        {
            String Felhasznalo = Nev.Text;
            if (Felhasznalo == "")
            {
                MessageBox.Show("Nem adtal nevet");
            }
            else
            {
                Name.Text = Felhasznalo;
                Score.Text = "0";
                BelepGomb.IsEnabled = false;
                Gomb.IsEnabled = true;
                Nev.IsEnabled = false;
            }
        }

        private void Gomb_Click(object sender, RoutedEventArgs e)
        {
            pp++;
            PontSzam.Text = pp + "";
            Score.Text = pp + "";
        }

        private void ResetGomb_Click(object sender, RoutedEventArgs e)
        {
            PontSzam.Text = 0 + "";
            Score.Text = 0 + "";
            Name.Text = "Név";
            BelepGomb.IsEnabled = true;
            Nev.IsEnabled = true;
            Nev.Text = "Név";
            Gomb.IsEnabled = false;
            pp = 0;
        }

        private void HSB_Click(object sender, RoutedEventArgs e)
        {
            HS.Items.Add(Name.Text + "     " + Score.Text);
        }
    }
}

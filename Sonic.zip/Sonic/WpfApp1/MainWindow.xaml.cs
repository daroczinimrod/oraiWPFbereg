﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void Szamol_Click(object sender, RoutedEventArgs e)
        {
            string torlo = Torlo.Text;
            string stat = Static.Text;
            double elso = 0;
            double masodik = 0;
            double harmadik = 0;
            double ma = 0;
            int myInt;
            bool isNumerical1 = int.TryParse(torlo, out myInt);
            int myInt2;
            bool isNumerical2 = int.TryParse(stat, out myInt2);


            if (isNumerical1 == true && isNumerical2 == true)
            {
                double qc = double.Parse(Torlo.Text);
                double po = double.Parse(Static.Text);
                elso = qc / po;
                elso++;
                masodik = Math.Pow(elso, 0.29);
                masodik--;
                harmadik = masodik * 5;
                ma = Math.Sqrt(harmadik);


                Eredmeny.Items.Add("qc=" + Torlo.Text + "  p0=" + Static.Text + "  Ma=" + ma);

                if (ma < 1 && ma > 0)
                {
                    MessageBox.Show("Szuperszonikus sebesség!");
                }
            }
            else
            {
                MessageBox.Show("Hibás formátum!");
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}

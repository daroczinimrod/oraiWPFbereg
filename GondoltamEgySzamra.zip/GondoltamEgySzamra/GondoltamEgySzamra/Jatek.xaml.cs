﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace GondoltamEgySzamra
{
    /// <summary>
    /// Interaction logic for Jatek.xaml
    /// </summary>
    public partial class Jatek : Window
    {
        public Jatek()
        {
            InitializeComponent();
            udv.Text = "Szia " + MainWindow.nev + "!  Készen állsz!";
        }
        public struct adat
        {
            public string felhasznalo;
            public string jelszo;
            public int nyert;
            public int vesztett;
        }

        public adat[] Bev(string na)
        {
            string[] t = File.ReadAllLines(na);
            adat[] ada = new adat[t.Length];


            for (int i = 0; i < ada.Length; i++)
            {
                string[] tt = t[i].Split(';');
                ada[i].felhasznalo = tt[0];
                ada[i].jelszo = tt[1];
                ada[i].nyert = int.Parse(tt[2]);
                ada[i].vesztett = int.Parse(tt[3]);
            }
            return ada;
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();

        }

        private void Jatszok_Click(object sender, RoutedEventArgs e)
        {
            Random rand = new Random();
            Szamok.Items.Clear();
            for (int i = 0; i < 3; i++)
            {
                int random = rand.Next(1, 11);
                Szamok.Items.Add(random);
            }

        }

        public int nyert2;
        public int vesztett2;

        private void mehet_Click(object sender, RoutedEventArgs e)
        {
            Random rando = new Random();
            int random2 = rando.Next(1, 4);

            if (Szamok.SelectedIndex == random2)
            {
                nyert2++;
                Nyert.Text = "Nyert: " + nyert2 + "x";
                MessageBox.Show("Nyertél");
            }
            else
            {
                vesztett2++;
                Vesztett.Text = "Vesztett: " + vesztett2 + "x";
                MessageBox.Show("Vesztettél!");
            }

            Szamok.Items.Clear();
        }
    }
    }


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace GondoltamEgySzamra
{
    /// <summary>
    /// Interaction logic for Regist.xaml
    /// </summary>
    public partial class Regist : Window
    {
        public struct adat
        {
            public string felhasznalo;
            public string jelszo;
            public int nyert;
            public int vesztett;
        }
        public Regist()
        {
            InitializeComponent();
            if (!File.Exists("save.txt"))
            {
                File.Create("save.txt");
            }
        }

        public adat[] Bev(string na)
        {
            string[] t = File.ReadAllLines(na);
            adat[] ada = new adat[t.Length];

            for (int i = 0; i < ada.Length; i++)
            {
                string[] tt = t[i].Split(';');
                ada[i].felhasznalo = tt[0];
                ada[i].jelszo = tt[1];
                ada[i].nyert = int.Parse(tt[2]);
                ada[i].vesztett = int.Parse(tt[3]);
            }
            return ada;
        }

        private void reg_Click(object sender, RoutedEventArgs e)
        {
            adat[] ttt = Bev("save.txt");
            string n = nv.Text;
            string j = js.Text;
            bool vane = false;
            int nyert1 = 0;
            int vesztett1 = 0;
            for (int i = 0; i < ttt.Length; i++)
            {
                if (n == ttt[i].felhasznalo)
                {
                    vane = true;
                }
            }
            if (vane == true)
            {
                MessageBox.Show("Már van ilyen felhasználó!");
                nv.Clear();
                js.Clear();
            }
            else
            {
                File.AppendAllText("save.txt", n + ";" + j + ";" + nyert1 + ";" + vesztett1 + "\n");
                MessageBox.Show("Sikeres regisztráció!");
            }
        }


        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            MainWindow main = new MainWindow();
            main.Show();
        }
    }
}

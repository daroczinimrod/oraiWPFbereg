﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Orai
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ki_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void reg_Click(object sender, RoutedEventArgs e)
        {
            Reg regis = new Reg();
            regis.Show();
            this.Close();
        }
        public struct adat
        {
            public string felhasznalo;
            public string jelszo;
        }


        public adat[] Bev(string na)
        {
            string[] t = File.ReadAllLines("users.txt");
            adat[] ada = new adat[t.Length];

            for (int i = 0; i < ada.Length; i++)
            {
                string[] tt = t[i].Split(';');
                ada[i].felhasznalo = tt[0];
                ada[i].jelszo = tt[1];
            }
            return ada;
        }
        public static string nev;

        private void bel_Click(object sender, RoutedEventArgs e)
        {
            adat[] ttt = Bev("users.txt");
            string n = nv.Text;
            nev = n;
            string j = js.Password;
            bool vane = false;
            for (int i = 0; i < ttt.Length; i++)
            {
                if (n == ttt[i].felhasznalo && j == ttt[i].jelszo)
                {
                    vane = true;
                }
            }
            if (vane)
            {
                Keres ablak = new Keres();
                ablak.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Nincs ilyen felhasználó!");
                nv.Clear();
                js.Clear();
            }
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace Orai
{
    /// <summary>
    /// Interaction logic for Reg.xaml
    /// </summary>
    public partial class Reg : Window
    {
        public Reg()
        {
            InitializeComponent();

        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        public struct adat
        {
            public string felhasznalo;
            public string jelszo;
        }


        public adat[] Bev(string na)
        {
           
            string[] t = File.ReadAllLines("users.txt");
            adat[] ada = new adat[t.Length];

            for (int i = 0; i < ada.Length; i++)
            {
                string[] tt = t[i].Split(';');
                ada[i].felhasznalo = tt[0];
                ada[i].jelszo = tt[1];
            }
            return ada;
        }


        private void reg_Click(object sender, RoutedEventArgs e)
        {

            adat[] ttt = Bev("users.txt");
            string n = nv.Text;
            string j = js.Text;
            bool vane = false;
            for (int i = 0; i < ttt.Length; i++)
            {
                if (n == ttt[i].felhasznalo)
                {
                    vane = true;
                }
            }
            if (vane == true)
            {
                MessageBox.Show("Már van ilyen felhasználó!");
                nv.Clear();
                js.Clear();
            }
            else
            {
                File.AppendAllText("users.txt", n + ";" + j + "\n");
                MessageBox.Show("Sikeres regisztráció!");
            }
        }


    }
}

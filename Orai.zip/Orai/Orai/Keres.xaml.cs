﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;


namespace Orai
{
    /// <summary>
    /// Interaction logic for Keres.xaml
    /// </summary>
    public partial class Keres : Window
    {
        public Keres()
        {
            InitializeComponent();
        }


        public struct adat
        {
            public string hnev;
            public string anev;
            public string ceg;
            public int fsz;
            public int ssz;
        }


        public adat[] Bev(string na)
        {
            string[] t = File.ReadAllLines("forras.txt");
            adat[] ada = new adat[t.Length];

            for (int i = 0; i < ada.Length; i++)
            {
                string[] tt = t[i].Split(';');
                ada[i].hnev = tt[0];
                ada[i].anev = tt[1];
                ada[i].ceg = tt[2];
                ada[i].fsz = int.Parse(tt[3]);
                ada[i].ssz = int.Parse(tt[4]);
            }
            return ada;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            eredmeny.Items.Clear();
            adat[] tt = Bev("users.txt");
            string megadott = beirt.Text;
            string kivalasztott = comb.Text;
            if (kivalasztott == "Bárhol")
            {
                foreach (var line in File.ReadAllLines("forras.txt"))
                {
                    if (line.Contains(megadott))
                    {
                        eredmeny.Items.Add(line);
                    }

                }
            }
            else if (kivalasztott == "Név")
            {
                adat[] ttt = Bev("users.txt");
                for (int i = 0; i < ttt.Length; i++)
                {
                    if (megadott == ttt[i].hnev)
                    {
                        eredmeny.Items.Add(ttt[i].hnev + ";" + ttt[i].anev + ";" + ttt[i].ceg + ";" + ttt[i].fsz + ";" + ttt[i].ssz);
                    }
                }
            }
            else if (kivalasztott == "Angol")
            {
                adat[] ttt = Bev("users.txt");
                for (int i = 0; i < ttt.Length; i++)
                {
                    if (megadott == ttt[i].anev)
                    {
                        eredmeny.Items.Add(ttt[i].hnev + ";" + ttt[i].anev + ";" + ttt[i].ceg + ";" + ttt[i].fsz + ";" + ttt[i].ssz);
                    }
                }
            }
            else if (kivalasztott == "Filmszereplések")
            {
                adat[] ttt = Bev("users.txt");
                for (int i = 0; i < ttt.Length; i++)
                {
                    if (int.Parse(megadott) == ttt[i].fsz)
                    {
                        eredmeny.Items.Add(ttt[i].hnev + ";" + ttt[i].anev + ";" + ttt[i].ceg + ";" + ttt[i].fsz + ";" + ttt[i].ssz);
                    }
                }
            }
            else if (kivalasztott == "Cég")
            {
                adat[] ttt = Bev("users.txt");
                for (int i = 0; i < ttt.Length; i++)
                {
                    if (megadott == ttt[i].ceg)
                    {
                        eredmeny.Items.Add(ttt[i].hnev + ";" + ttt[i].anev + ";" + ttt[i].ceg + ";" + ttt[i].fsz + ";" + ttt[i].ssz);
                    }
                }
            }
            else if (kivalasztott == "Sorozatszereplés")
            {
                adat[] ttt = Bev("users.txt");
                for (int i = 0; i < ttt.Length; i++)
                {
                    if (int.Parse(megadott) == ttt[i].ssz)
                    {
                        eredmeny.Items.Add(ttt[i].hnev + ";" + ttt[i].anev + ";" + ttt[i].ceg + ";" + ttt[i].fsz + ";" + ttt[i].ssz);
                    }
                }
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }


        private void Kilep_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Next_Click_1(object sender, RoutedEventArgs e)
        {
            if (Valasztott.Text == "C to F")
            {
                Kmbox.IsEnabled = false;
                Kmcon.IsEnabled = false;
                Kmvalt.IsEnabled = false;
                Cbox.IsEnabled = true;
                Ccon.IsEnabled = true;
                Cvalt.IsEnabled = true;
                Kgbox.IsEnabled = false;
                Kgcon.IsEnabled = false;
                Kgvalt.IsEnabled = false;
            }
            else if (Valasztott.Text == "Kg to g")
            {
                Kmbox.IsEnabled = false;
                Kmcon.IsEnabled = false;
                Kmvalt.IsEnabled = false;
                Kgbox.IsEnabled = true;
                Kgcon.IsEnabled = true;
                Kgvalt.IsEnabled = true;
                Cbox.IsEnabled = false;
                Ccon.IsEnabled = false;
                Cvalt.IsEnabled = false;
            }
            else if (Valasztott.Text == "Km to Mph")
            {
                Kmbox.IsEnabled = true;
                Kmcon.IsEnabled = true;
                Kmvalt.IsEnabled = true;
                Cbox.IsEnabled = false;
                Ccon.IsEnabled = false;
                Cvalt.IsEnabled = false;
                Kgbox.IsEnabled = false;
                Kgcon.IsEnabled = false;
                Kgvalt.IsEnabled = false;
            }
            
        }

        private void Kmcon_Click(object sender, RoutedEventArgs e)
        {
            if (Kmbox.IsEnabled == true)
            {
                double km = double.Parse(Kmbox.Text);
                double valto = 1.609344;
                Kmbox2.Text = km / valto + "";
            }
            else if (Kmbox.IsEnabled == false)
            {
                double Mph = double.Parse(Kmbox2.Text);
                double valto = 1.609344;
                Kmbox.Text = Mph * valto + "";
            }

                       
        }

        private void Kmvalt_Click(object sender, RoutedEventArgs e)
        {
            Kmbox2.IsEnabled = true;
            Kmbox.IsEnabled = false;



        }
        private void Ccon_Click(object sender, RoutedEventArgs e)
        {
            if (Cbox.IsEnabled == true)
            {
                double C = double.Parse(Cbox.Text);
                double valto = 1.8;
                Cbox2.Text = C * valto + 32 + "";
            }
            else if (Cbox.IsEnabled == false)
            {
                double F = double.Parse(Cbox2.Text);
                double valto = 1.8;
                Cbox.Text = F - 32 / valto + "";
            }
        }

        private void Cvalt_Click(object sender, RoutedEventArgs e)
        {
            Cbox2.IsEnabled = true;
            Cbox.IsEnabled = false;

        }

        private void Kgcon_Click(object sender, RoutedEventArgs e)
        {
            if (Kgbox.IsEnabled == true)
            {
                double kg = double.Parse(Kgbox.Text);
                double valto = 1000;
                Kgbox2.Text = kg * valto + "";
            }
            else if (Kgbox.IsEnabled == false)
            {
                double g = double.Parse(Kgbox2.Text);
                double valto = 1000;
                Kgbox.Text = g / valto + "";
            }
        }

        private void Kgvalt_Click(object sender, RoutedEventArgs e)
        {
            Kgbox2.IsEnabled = true;
            Kgbox.IsEnabled = false;
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            Kgbox.Text = "";
            Kgbox2.Text = "";
            Cbox.Text = "";
            Cbox2.Text = "";
            Kmbox.Text = "";
            Kmbox2.Text = "";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

       
                private void Gomb_Click(object sender, RoutedEventArgs e)
        {
            string Sajat = 0 + "";
            string Ellen = 0 + "";
            
            Random rand = new Random();
            int Sors = rand.Next(1, 4);

            if (Sors == 1)
            {
                Ellenfel.Text = "Kő";
            }
            else if (Sors == 2)
            {
                Ellenfel.Text = "Papír";
            }
            else
            {
                Ellenfel.Text = "Olló";
            }

            if (Valasztas.Text == "Kő" && Ellenfel.Text == "Papír")
            {
                Ellen = Ellen + 1;
                MessageBox.Show("Vesztettél");
            }
            else if (Valasztas.Text == "Kő" && Ellenfel.Text == "Olló")
            {
                Sajat = Sajat + 1;
                MessageBox.Show("Te nyertél");
            }
            else if (Valasztas.Text == "Kő" && Ellenfel.Text == "Kő")
            {
                Sajat = Sajat + 1;
                MessageBox.Show("Te nyertél");
            }
            else if (Valasztas.Text == "Kő" && Ellenfel.Text == "Olló")
            {
                Ellen = Ellen + 1;
                MessageBox.Show("Vesztettél");
            }
            else if (Valasztas.Text == "Kő" && Ellenfel.Text == "Kő")
            {
                Ellen = Ellen + 1;
                MessageBox.Show("Vesztettél");
            }
            else if (Valasztas.Text == "Kő" && Ellenfel.Text == "Papír")
            {
                Sajat = Sajat + 1;
                MessageBox.Show("Te nyertél");
            }
            else
            {
                MessageBox.Show("Döntetlen");
            }

        }
    }
}
